package com.example.foodorder.listener

import com.example.foodorder.model.Food

interface IOnClickFoodItemListener {
    fun onClickItemFood(food: Food)
}